//
//  ViewController.m
//  PlistProgramatically
//
//  Created by Student 6 on 11/04/17.
//  Copyright © 2017 felix. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    NSMutableArray *arrMut;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray *arr=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentPath=[arr objectAtIndex:0];
    NSString *strPlistPath=[documentPath stringByAppendingPathComponent:@"student.plist"];
    NSFileManager *manager=[NSFileManager defaultManager];

    
    if ([manager fileExistsAtPath:strPlistPath]) {
            arrMut=[[NSMutableArray alloc]initWithContentsOfFile:strPlistPath];
    }else{
        arrMut=[[NSMutableArray alloc]init];
        NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
        [dict setObject:@"Priya" forKey:@"name"];
        [dict setObject:@2 forKey:@"id"];
        [arrMut addObject:dict];

        [arrMut writeToFile:strPlistPath atomically:YES];
        
        [dict setObject:@"Abhijit" forKey:@"name"];
        [dict setObject:@3 forKey:@"id"];
        [arrMut addObject:dict];
        
        [arrMut writeToFile:strPlistPath atomically:YES];
        NSLog(@"%@",arrMut);
    }
    if (arrMut.count) {
        
        // Table Load
    }
    
    
    
    
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
